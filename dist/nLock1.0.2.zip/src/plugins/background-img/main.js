var body = document.body;
if(body){
	body.style.background='url(http://lorempixel.com/400/200/)';
	body.style.backgroundSize='100% 100%';
}
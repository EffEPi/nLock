var divs=document.getElementsByTagName("div");
for(var i=0; i<divs.length; i++){
	divs[i].style.background='url(http://lorempixel.com/400/200/)';
	divs[i].style.backgroundSize='100% 100%';
}